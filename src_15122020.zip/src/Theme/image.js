const AppImages =
{
    Family: require('../images/family.png'),
    add_user: require('../images/add.png'),
    news: require('../images/news.png'),
    events: require('../images/events.png'),
    property: require('../images/property.png'),
    matromoney: require('../images/matromoney.png'),
    Employment: require('../images/Employment.png'),
    gallery: require('../images/gallery.png'),
    circular: require('../images/circular.png'),
    businessinfo: require('../images/businessinfo.png'),
    suggestion: require('../images/suggestion.png'),
    familytree: require('../images/familytree.png'),
    donors: require('../images/donors.png'),
    faqs: require('../images/faqs.png'),
    plan: require('../images/plan.png'),
    karobari: require('../images/karobari.png'),
    contactus: require('../images/contact.png'),
    committe: require('../images/committe.png'),
    about: require('../images/info.png'),
    placeHolder:require('../images/placeholder.png'),
    wishlist:require('../images/wishlist.png'),
    logo:require('../images/samaj.png'),
    

}
export default AppImages