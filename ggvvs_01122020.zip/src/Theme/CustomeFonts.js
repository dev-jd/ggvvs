const CustomeFonts =
{
    regular: 'Poppins-Regular',
    bold: 'Poppins-Bold',
    medium: 'Poppins-Medium'
 
}
export default CustomeFonts