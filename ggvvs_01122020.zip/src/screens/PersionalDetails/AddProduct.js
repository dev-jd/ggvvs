import React, { Component } from 'react'
import {
    Form, Text, View, ScrollView, TouchableOpacity, Switch, ActivityIndicator,
  SafeAreaView
} from 'react-native'
import CustomeFonts from '../../Theme/CustomeFonts'
import Style from '../../Theme/Style'
import Colors from '../../Theme/Colors'
import axois from 'axios'
import { base_url } from '../../Static'
import Toast from 'react-native-simple-toast'
import AsyncStorage from '@react-native-community/async-storage'
import NetInfo from "@react-native-community/netinfo";
import WebView from 'react-native-webview'

export default class AddProduct extends Component {
    static navigationOptions = ({ navigation }) => {
      return {
        title: 'Add Product',
        headerTitleStyle: {
          width: '100%',
          fontWeight: '200',
          fontFamily: CustomeFonts.regular
        }
      }
    }

    constructor() {
        super()
        this.state = {
            samaj_id: '',
            member_id: '',
            member_type: '',
            name:'',
            description:'',
            category:'',
            subcategory:'',
            videolink:'',
        }
    }

    async componentWillMount() {
        
        const samaj_id = await AsyncStorage.getItem('member_samaj_id')
        const member_id = await AsyncStorage.getItem('member_id')
        const member_type = await AsyncStorage.getItem('type')
    
        this.setState({
          samaj_id: samaj_id,
          member_id: member_id,
          member_type: member_type,
        })
    
        await NetInfo.addEventListener(state => {
          console.log('Connection type', state.type)
          console.log('Is connected?', state.isConnected)
          this.setState({ connection_Status: state.isConnected })
        })
      }

      async editData() {
        this.setState({ isLoading: true })
        const formData = new FormData()
        formData.append('samaj_id', this.state.cmpName)
        formData.append('member_id', this.state.designation)
        formData.append('member_type', this.state.cmpAddress)
        formData.append('name', this.state.cmpPhone)
        formData.append('description', this.state.member_id)
        formData.append('category', this.state.samaj_id)
        formData.append('subcategory', this.state.countrytatus)
        formData.append('videolink', this.state.statetatus)

        // if (
        //     this.state.photoPath === '' ||
        //     this.state.photoPath === null || this.state.photoPath === 'null' ||
        //     this.state.photoPath === undefined
        // ) {
        //     formData.append('business_logo', this.state.photoImage)
        // } else {
        //     formData.append('business_logo', {
        //         uri: 'file://' + this.state.photoPath,
        //         name: this.state.photoFileName,
        //         type: this.state.photoType
        //     })
        // }

        console.log("formdata-->", formData)

        if (this.state.connection_Status) {
            axois.post(base_url + 'productAdd', formData)
                .then(res => {
                    console.log("productAdd--->", res.data)
                    this.setState({ isLoading: false })
                    if (res.data.status === true) {
                        Toast.show(res.data.message)
                        this.props.navigation.navigate('Dashboard')
                    } else {
                        Toast.show(res.data.message)
                    }
                })
                .catch(err => {
                    this.setState({ isLoading: false })
                    console.log("professional_details_edit err", err)
                })
        } else {
            Toast.show("No Internet Connection")
        }
    }

    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={Style.cointainer}>
                        <View style={[Style.cardback, style = { flex: 1, justifyContent: 'center', marginTop: 10, }]}>

                            <Form>
                                <Item stackedLabel>
                                    <Label style={[Style.Textstyle, style = { color: Colors.black, fontFamily: CustomeFonts.medium }]}>
                                        Product Name</Label>
                                    <Input style={Style.Textstyle}
                                        multiline={false}
                                        onChangeText={(value) => this.setState({ name: value })}
                                        value={this.state.cmpName}
                                        maxLength={60}
                                    >
                                    </Input>
                                </Item>
                            </Form>
                            <Form>
                                <Item stackedLabel>
                                    <Label style={[Style.Textstyle, style = { color: Colors.black, fontFamily: CustomeFonts.medium }]}>
                                        Description</Label>
                                    <Input style={Style.Textstyle}
                                        multiline={false}
                                        keyboardType='numeric'
                                        maxLength={13}
                                        minLength={8}
                                        onChangeText={(value) => this.setState({ description: value })}
                                        value={this.state.description}
                                    >
                                    </Input>
                                </Item>
                            </Form>
                            <Form>
                                <Item stackedLabel>
                                    <Label style={[Style.Textstyle, style = { color: Colors.black, fontFamily: CustomeFonts.medium }]}>
                                    Category</Label>
                                    <Input style={Style.Textstyle}
                                        multiline={false}
                                        onChangeText={(value) => this.setState({ category: value })}
                                        value={this.state.category}
                                    >
                                    </Input>
                                </Item>
                            </Form>
                            <Form>
                                <Item stackedLabel>
                                    <Label style={[Style.Textstyle, style = { color: Colors.black, fontFamily: CustomeFonts.medium }]}>
                                    Sub Category</Label>
                                    <Input style={Style.Textstyle}
                                        multiline={false}
                                        onChangeText={(value) => this.setState({ subcategory: value })}
                                        value={this.state.subcategory}
                                    >
                                    </Input>
                                </Item>
                            </Form>
                            <Form>
                                <Item stackedLabel>
                                    <Label style={[Style.Textstyle, style = { color: Colors.black, fontFamily: CustomeFonts.medium }]}>
                                    Video Link</Label>
                                    <Input style={Style.Textstyle}
                                        multiline={false}
                                        onChangeText={(value) => this.setState({ videolink: value })}
                                        value={this.state.videolink}
                                        maxLength={20}
                                    >
                                    </Input>
                                </Item>
                            </Form>

                        </View>
                        {this.state.isLoading ?
                            <ActivityIndicator size={'large'} color={Colors.Theme_color} />
                            :
                            <TouchableOpacity
                                style={[Style.Buttonback, (style = { marginTop: 10 })]}
                                onPress={() => this.editData()}
                            >
                                <Text style={Style.buttonText}>Update Details</Text>
                            </TouchableOpacity>
                        }
                    </View>
                </ScrollView>
            </SafeAreaView>
        );
    }
}