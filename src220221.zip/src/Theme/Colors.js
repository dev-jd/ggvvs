const Colors={

    white:'#ffffff',
    lightwhite:'#eeeeee95',
    red:'#F58634',
    black:'#000000',
    blackTp:'#00000085',
    divider : '#E8EBED',
    light_pink:'#faebf1',
    lightThem:'#FDD8BF',

    Theme_color:'#F58634',
    activeTabColor:'#F58634',
    inactiveTabColor:'#726f6f',

    // Persional details usage
    blue:'blue'
} 

export default Colors